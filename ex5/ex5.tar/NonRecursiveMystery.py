###################################################################
# FILE: NonRecursiveMystery.py
# WRITER: Aviad Levy
# EXERCISE : intro2cs ex5 2013-2014
# Description
# mystery_computation - a function that get a number and return the
#                       summarize of all the number who divide him
###################################################################
def mystery_computation(number):
    '''a function that get a number and return the summarize of all
    the number who are the factors (divisors) of the number'''
    ONE = 1
    result = 0
    #loop goes over all the numbers
    for index in range(ONE,number):
        #if is divisor -> summarize
        if number % index == 0:
            result += index
    return result
